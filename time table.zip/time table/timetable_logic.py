# timetable_logic.py
class TimetableLogic:
    def __init__(self, db, app=None):
        self.db = db
        self.app = app